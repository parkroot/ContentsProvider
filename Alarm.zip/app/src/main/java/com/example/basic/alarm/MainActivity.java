package com.example.basic.alarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    AlarmManager mAlMan;
    PendingIntent mPendInt;
    Calendar cal=Calendar.getInstance();
    Java.util.Date date=cal.getTime();
    String today=(new SimpleDateFormat("yyyyMMddHHmmss").format(date));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAlMan = (AlarmManager) getSystemService(ALARM_SERVICE);
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        mPendInt = PendingIntent.getActivity(this, 0, i, 0);
    }

    public void setAlarm1(View view) {
        int sec;
        String s;
        EditText txt = null;
        txt = (EditText)findViewById(R.id.edit1);
        s = txt.getText().toString();

        sec = Integer.parseInt(s);

        cal.setTimeInMillis(System.currentTimeMillis());
        cal.add(Calendar.SECOND, sec);
        mAlMan.set(AlarmManager.RTC, cal.getTimeInMillis(), mPendInt);
    }

    public void setAlarmR(View view) {
        mAlMan.setRepeating(AlarmManager.ELAPSED_REALTIME,
                SystemClock.elapsedRealtime(), 3000, mPendInt);
    }

    public void cancelAlarm(View view) {
        mAlMan.cancel(mPendInt);
    }
}